package com.constants;


public interface DBKey {



    /**
     * Table Column *
     */
     String JBLEQ = "JBLEQ";
     String EQ_NAME = "name";
     String ID = "_id";
     String HIGH1 = "HIGH1";
     String HIGH2 = "HIGH2";
     String HIGH3 = "HIGH3";

     String MEDIUM1 = "MEDIUM1";
     String MEDIUM2 = "MEDIUM2";
     String MEDIUM3 = "MEDIUM3";
     String MEDIUM4 = "MEDIUM4";

     String LOW1 = "LOW1";
     String LOW2 = "LOW2";
     String LOW3 = "LOW3";

    public  final static String IsAllDefaultInserted="IsAllDefaultInserted";
}
