package com.constants;


public class Actions {
    public  static final String HeadPhoneConnected="android.intent.action.HEADSET_PLUG";
}
